"""
Definition of models.
"""
from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin

class Mistnost(models.Model):
    nazev = models.CharField(verbose_name='Označení místnosti',max_length=50)
    def __str__(self):
        return self.nazev
    class Meta:
        verbose_name_plural = "Místnosti"

class Skupina(models.Model):
    nazev = models.CharField(verbose_name='Název skupiny',max_length=50, blank=False)
    listClenu= models.ManyToManyField(User, blank=True,verbose_name='Seznam členů')
    TYM_CHOICES = (('moznost1','Moznost1'),('moznost2','Moznost2'))
    PRACOVISTE_CHOICES = (('moznost1','Moznost1'),('moznost2','Moznost2'))
    PRODUKT_CHOICES = (('moznost1','Moznost1'),('moznost2','Moznost2'))
    tym = models.TextField(verbose_name='Tým',choices = TYM_CHOICES, blank=True)
    pracoviste = models.TextField(verbose_name='Pracoviště',choices = PRACOVISTE_CHOICES, blank=True)
    mistnosti= models.ManyToManyField(Mistnost, blank=True,verbose_name='Seznam místností')
    produkt = models.TextField(verbose_name='Produkt',choices = PRODUKT_CHOICES, blank=True)
    def __str__(self):
        return self.nazev
    class Meta:
        verbose_name_plural = "Skupiny"

class Zamestnanec(models.Model):
    STAV_CHOICES = (('normalni','Normalní'),('blokovany','Blokovaný'))
    user = models.OneToOneField(User, on_delete=models.CASCADE, blank=False)
    stav_uctu = models.TextField(verbose_name='Stav účtu',choices = STAV_CHOICES, default=STAV_CHOICES[0])
    """skupiny = models.TextField(choices = [(x, str(x)) for x in Skupina.objects.only('nazev')])"""
    """Získá všechny skupiny"""
    skupiny = models.ForeignKey(Skupina, on_delete=models.SET_NULL, null=True, blank=True,verbose_name='Skupiny')
    def __str__(self):
        return self.user.first_name + ' "'+ self.user.username +'" ' + self.user.last_name
    class Meta:
        verbose_name_plural = "Zaměstnanec"

class Vozidlo(models.Model):
    jmeno = models.CharField(verbose_name='Jméno vozidla',max_length=50, blank=False)
    popis = models.CharField(verbose_name='Popis',max_length=50, blank=False)
    upozorneni = models.CharField(verbose_name='UPOZORNĚNÍ! ',max_length=250, blank=True)
    blokovano = models.BooleanField(verbose_name='Blokováno', blank=False, default=False)
    spz = models.CharField(verbose_name='SPZ',max_length=30, blank=False)
    def __str__(self):
        return self.jmeno
    class Meta:
        verbose_name_plural = "Vozidla"

class Technika(models.Model):
    TECHNIKA_CHOICES = (('adapter','Adaptér'),('projektor','Projektor'),('jine','Jiné'))
    nazev = models.CharField(verbose_name='Název',max_length=50, blank=False)
    typ = models.CharField(verbose_name='Typ',max_length=50,blank=True, null=True)
    kategorie = models.TextField(verbose_name='Kategorie',choices = TECHNIKA_CHOICES)
    def __str__(self):
        return self.nazev
    class Meta:
        verbose_name_plural = "Technika"

class Udalost(models.Model):
    TYP_CHOICES = (('dovolena','Dovolená'),('sluzebni cesta','Služební cesta'),('rezervace','Rezervace'),('jine','Jiné'))
    nazev = models.CharField(verbose_name='Název',max_length=50, blank=False,null=True)
    start = models.DateTimeField(verbose_name='Start',blank=False)
    konec = models.DateTimeField(verbose_name='Konec',blank=False)
    typ = models.TextField(verbose_name='Typ události',choices=TYP_CHOICES,default='jine',null=True)
    listOsob = models.ManyToManyField(User, blank=True,verbose_name='Zahrnutí lidé')
    listSkupin = models.ManyToManyField(Skupina, blank=True,verbose_name='Zahrnuté skupiny')
    listVozidel = models.ManyToManyField(Vozidlo,blank=True,verbose_name='Zahrnutá vozidla')
    listTechniky = models.ManyToManyField(Technika, blank=True,verbose_name='Zahrnutá technika')
    listMistnosti = models.ManyToManyField(Mistnost, blank=True,verbose_name='Zahrnuté místnosti')
    def __str__(self):
        return str(self.id) + ": " + self.nazev
    class Meta:
        verbose_name_plural = "Události"
