"""
Definition of views.
"""

from datetime import datetime
from django.shortcuts import render
from django.http import HttpRequest
from django.contrib.auth import authenticate, login
from django.shortcuts import redirect
from django.contrib.auth.models import User
from django.core import serializers
from .models import Technika
from .models import Skupina
from .models import Vozidlo
from .models import Zamestnanec
from .models import Mistnost
from .models import Udalost


def home(request):
    allEvents = [None]
    if (request.session.get('_allEvents', None) != None):
        for id in request.session['_allEvents']:
            allEvents.append(Udalost.objects.get(id=id))
        del allEvents[0]
        del request.session['_allEvents']
        request.session.modified = True
    else:
        allEvents = Udalost.objects.all().distinct()
    if not request.user.is_authenticated:
        return redirect('/login')
    assert isinstance(request, HttpRequest)
    return render(request,
            'app/index.html',
            {
                'title':'Home Page',
                'year':datetime.now().year,
                'allUsers':Zamestnanec.objects.all(),
                'allEvents': allEvents,
                'allCars': Vozidlo.objects.all(),
                'allRooms': Mistnost.objects.all(),
                'allEquipment': Technika.objects.all(),
                'allGroups':Skupina.objects.all(),
            })


def auta(request):    
    allEvents = [None]
    if (request.session.get('_allEvents', None) != None):
        for id in request.session['_allEvents']:
            allEvents.append(Udalost.objects.get(id=id))
        del allEvents[0]
        del request.session['_allEvents']
        request.session.modified = True
        allEvents = [x for x in allEvents if x.listVozidel != None]
    else:
        allEvents = Udalost.objects.all().exclude(listVozidel__isnull=True)
    if not request.user.is_authenticated:
        return redirect('/login')
    assert isinstance(request, HttpRequest)
    return render(request,
            'app/auta.html',
            {
                'title':'Auta - kalendar',
                'year':datetime.now().year,
                'allUsers':Zamestnanec.objects.all(),
                'allEvents':allEvents,
                'allCars': Vozidlo.objects.all(),
                'allRooms': Mistnost.objects.all(),
                'allEquipment': Technika.objects.all(),
                'allGroups':Skupina.objects.all(),
            })


def mistnosti(request):
    allEvents = [None]
    if (request.session.get('_allEvents', None) != None):
        for id in request.session['_allEvents']:
            allEvents.append(Udalost.objects.get(id=id))
        del allEvents[0]
        del request.session['_allEvents']
        request.session.modified = True
        allEvents = [x for x in allEvents if x.listMistnosti != None]
    else:
        allEvents = Udalost.objects.all().exclude(listMistnosti__isnull=True)
    if not request.user.is_authenticated:
        return redirect('/login')
    assert isinstance(request, HttpRequest)
    return render(request,
            'app/mistnosti.html',
            {
                'title':'Mistnosti - kalendar',
                'year':datetime.now().year,
                'allUsers':Zamestnanec.objects.all(),
                'allEvents': allEvents,
                'eventClass':Udalost,
                'allCars': Vozidlo.objects.all(),
                'allRooms': Mistnost.objects.all(),
                'allEquipment': Technika.objects.all(),
                'allGroups':Skupina.objects.all(),
            })  

def technika(request):
    allEvents = [None]
    if (request.session.get('_allEvents', None) != None):
        for id in request.session['_allEvents']:
            allEvents.append(Udalost.objects.get(id=id))
        del allEvents[0]
        del request.session['_allEvents']
        request.session.modified = True
        allEvents = [x for x in allEvents if x.listTechniky != None]
    else:
        allEvents = Udalost.objects.all().exclude(listTechniky__isnull=True)
    if not request.user.is_authenticated:
        return redirect('/login')
    assert isinstance(request, HttpRequest)
    return render(request,
            'app/vybaveni.html',
            {
                'title':'Technika - kalendar',
                'year':datetime.now().year,
                'udalostClass':Udalost,
                'allUsers':Zamestnanec.objects.all(),
                'allEvents': allEvents,
                'allCars': Vozidlo.objects.all(),
                'allRooms': Mistnost.objects.all(),
                'allEquipment': Technika.objects.all(),
                'allGroups':Skupina.objects.all(),
                
            })    

def osoby(request):
    allEvents = [None]
    if (request.session.get('_allEvents', None) != None):
        for id in request.session['_allEvents']:
            allEvents.append(Udalost.objects.get(id=id))
        del allEvents[0]
        del request.session['_allEvents']
        request.session.modified = True
        allEvents = [x for x in allEvents if x.listOsob != None]
    else:
        allEvents = Udalost.objects.all().exclude(listOsob__isnull=True)
    if not request.user.is_authenticated:
        return redirect('/login')
    assert isinstance(request, HttpRequest)
    return render(request,
            'app/osoby.html',
            {
                'title':'Osoby - kalendar',
                'year':datetime.now().year,
                'allUsers':Zamestnanec.objects.all(),
                'allEvents': allEvents,
                'allCars': Vozidlo.objects.all(),
                'allRooms': Mistnost.objects.all(),
                'allEquipment': Technika.objects.all(),
                'allGroups':Skupina.objects.all(),
            })

def createEvent(request):
    next = request.POST.get('next', 'app/index.html')     
    selectedEvent = int(request.POST.get('ModifySelectedEvent',-1))
    if request.method == 'POST':
        if selectedEvent == -1:
            event = Udalost()
        else:
            event = Udalost.objects.get(pk=selectedEvent)
        event.nazev = request.POST.get('nazev')
        event.start = request.POST.get('zacatek') 
        event.konec = request.POST.get('konec')
        event.typ = request.POST.get('typ')
        if event.nazev == '' or event.start == '' or event.konec == "":
            return redirect(next)
        else:
            if selectedEvent == -1:
                event.save()
            try:
                event.listOsob.clear()
                event.listSkupin.clear()
                event.listTechniky.clear()
                event.listMistnosti.clear()
                if request.POST.get('osoby') is not None:
                    for item in request.POST.get('osoby'):
                        event.listOsob.add(item)

                if request.POST.get('skupiny') is not None:
                    for item in request.POST.get('skupiny'):
                        event.listSkupin.add(item)

                if request.POST.get('auta') is not None:
                    for item in request.POST.get('auta'):
                        event.listVozidel.add(item)

                if request.POST.get('vybaveni') is not None:
                    for item in request.POST.get('vybaveni'):
                        event.listTechniky.add(item)

                if request.POST.get('mistnosti') is not None:
                    for item in request.POST.get('mistnosti'):
                        event.listMistnosti.add(item)
                event.save()
                return redirect(next)
            except Exception as e:
                print(e.message, type(e))
                event.delete()
                return redirect(next)
    else:
        return redirect(next)

def loadEvents(request):
    next = request.POST.get('next', 'app/index.html')     
    if request.method == 'POST':
        arguments = [int(request.POST.get('osoba')),int(request.POST.get('vybaveni')),int(request.POST.get('skupina')),int(request.POST.get('auto')),int(request.POST.get('mistnost'))]
        proceed = False
        for value in arguments:
            if value is not -1:
                proceed = True
        if proceed is True:
            allEvents = Udalost.objects.filter(listOsob__id=int(arguments[0])) | Udalost.objects.filter(listTechniky__id=int(arguments[1])) | Udalost.objects.filter(listSkupin__id=int(arguments[2])) | Udalost.objects.filter(listVozidel__id=int(arguments[3])) | Udalost.objects.filter(listMistnosti__id=int(arguments[4]))
            allEvents = allEvents.distinct()
        else:
            allEvents = Udalost.objects.all()
        allEvents = list(allEvents.distinct())
        for index, event in enumerate(allEvents):
            allEvents[index] = event.id
        request.session['_allEvents'] = list(allEvents)
        return redirect(next)
    else:
        return redirect(next)

def deleteEvent(request):
    next = request.POST.get('next', 'app/index.html')     
    if request.method == 'POST':
        selectedIndex = request.POST.get('SelectedEventId', -1)    
        if selectedIndex !=-1:
            Udalost.objects.get(id=selectedIndex).delete()
        return redirect(next)