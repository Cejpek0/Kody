﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArduinoLCD
{
    public partial class Form1 : Form
    {
        MusicBeeIPC musicBee = new MusicBeeIPC();
        Timer timer = new Timer();
        
        public Form1()
        {
            InitializeComponent();
            ArduinoUpdate();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ArduinoUpdate();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            ArduinoUpdate();
        }
        private void ArduinoUpdate()
        {
            SerialPort port = new SerialPort("COM3", 9600, Parity.None, 8, StopBits.One);
            port.Open();
            port.Write(musicBee.GetFileTag(MusicBeeIPC.MetaData.TrackTitle) + "\t" + musicBee.GetFileTag(MusicBeeIPC.MetaData.Artist) + "\n");
            port.Close();
        }
    }
}
