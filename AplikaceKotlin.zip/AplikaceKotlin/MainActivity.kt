package com.example.coopcounter

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.opengl.Visibility
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.View.GONE
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat.startActivity
import androidx.core.view.isNotEmpty
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_friends.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.adView
import kotlinx.android.synthetic.main.appbar.*

private lateinit var auth: FirebaseAuth
val Mycounters:MutableList<Counter> = arrayListOf();
val Othercounters:MutableList<Counter> = arrayListOf();
var AllFriends:MutableList<User> = arrayListOf();
var involvedUsers:MutableList<Boolean> = arrayListOf();
var friendsLoaded = false;
var focusedCounter:Counter = Counter("",0,"","","",CounterTypes.Solo, arrayListOf(),0);
var allRequests: MutableList<Request> = arrayListOf()
lateinit var recycleCoopUsers:RecyclerView;
lateinit var currentUser:User;
lateinit var mainContext:Context;
lateinit var publicRecCounter:RecyclerView
lateinit var _menu:Menu
var connection = false;
class MainActivity : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var toolBar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolBar!!)
        MobileAds.initialize(this,getString(R.string.admob_app_id))
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        mainContext = this@MainActivity;
        publicRecCounter = recCounter
        friendsLoaded = false;
        Mycounters.clear();
        Othercounters.clear();
        AllFriends.clear();
        involvedUsers = arrayListOf();
        rotateCounterClockWise.duration = 150;
        rotateCounterClockWise.interpolator = LinearInterpolator()
        rotateClockWise.duration = 150;
        rotateClockWise.interpolator = LinearInterpolator()
        var connectionChecked = false;
        val dialog = AlertDialog.Builder(this,R.style.CreateCounterTheme)
        val dialogView = layoutInflater.inflate(R.layout.message_add_counter,null);
        val txtName = dialogView.findViewById<EditText>(R.id.txtCounterName);
        val chboxCoop = dialogView.findViewById<LottieAnimationView>(R.id.chboxCoop);
        val chboxGame = dialogView.findViewById<LottieAnimationView>(R.id.chboxGame);
        var relCoop = dialogView.findViewById<RelativeLayout>(R.id.layoutCoop)
        var relGame = dialogView.findViewById<RelativeLayout>(R.id.layoutGame)
        recycleCoopUsers = dialogView.findViewById<RecyclerView>(R.id.recycleCoopUsers);
        val handler: Handler = Handler(Looper.getMainLooper());
        var wi_fi = findViewById<LottieAnimationView>(R.id.wi_fi)
        wi_fi.progress = .5f;
        val networkManager = NetworkManager(this)

        fun continueMain() //Hlavní program*****************************
        {
            var coopIsChecked = false;
            var gameIsChecked = false;



            chboxCoop.setOnClickListener{
                coopIsChecked = !coopIsChecked;
                if(coopIsChecked)
                {
                    chboxCoop.setMinAndMaxProgress(0f,0.5f)
                    chboxCoop.speed = 1.5f;
                    chboxCoop.playAnimation()

                    recycleCoopUsers.visibility =  android.view.View.VISIBLE;
                    if(gameIsChecked)
                    {
                        chboxGame.setMinAndMaxProgress(0f,0.5f)
                        chboxGame.speed = -1.5f;
                        chboxGame.playAnimation()
                    }

                    gameIsChecked = false;
                }
                else{
                    chboxCoop.setMinAndMaxProgress(0f,0.5f)
                    chboxCoop.speed = -1.5f;
                    chboxCoop.playAnimation()
                    recycleCoopUsers.visibility = GONE;
                }
            }
            relCoop.setOnClickListener{
                coopIsChecked = !coopIsChecked;
                if(coopIsChecked)
                {
                    chboxCoop.setMinAndMaxProgress(0f,0.5f)
                    chboxCoop.speed = 1.5f;
                    chboxCoop.playAnimation()

                    recycleCoopUsers.visibility =  android.view.View.VISIBLE;
                    if(gameIsChecked)
                    {
                        chboxGame.setMinAndMaxProgress(0f,0.5f)
                        chboxGame.speed = -1.5f;
                        chboxGame.playAnimation()
                    }

                    gameIsChecked = false;
                }
                else{
                    chboxCoop.setMinAndMaxProgress(0f,0.5f)
                    chboxCoop.speed = -1.5f;
                    chboxCoop.playAnimation()
                    recycleCoopUsers.visibility = GONE;
                }
            }
            chboxGame.setOnClickListener{
                gameIsChecked = !gameIsChecked;
                if(gameIsChecked)
                {
                    chboxGame.setMinAndMaxProgress(0f,0.5f)
                    chboxGame.speed = 1.5f;
                    chboxGame.playAnimation()
                    if(coopIsChecked)
                    {
                        chboxCoop.setMinAndMaxProgress(0f,0.5f)
                        chboxCoop.speed = -1.5f;
                        chboxCoop.playAnimation()
                    }
                    coopIsChecked = false;
                    recycleCoopUsers.visibility =  android.view.View.VISIBLE;

                }
                else{
                    chboxGame.setMinAndMaxProgress(0f,0.5f)
                    chboxGame.speed = -1.5f;
                    chboxGame.playAnimation()
                    recycleCoopUsers.visibility = GONE;
                }
            }
            relGame.setOnClickListener{
                gameIsChecked = !gameIsChecked;
                if(gameIsChecked)
                {
                    chboxGame.setMinAndMaxProgress(0f,0.5f)
                    chboxGame.speed = 1.5f;
                    chboxGame.playAnimation()
                    if(coopIsChecked)
                    {
                        chboxCoop.setMinAndMaxProgress(0f,0.5f)
                        chboxCoop.speed = -1.5f;
                        chboxCoop.playAnimation()
                    }
                    coopIsChecked = false;
                    recycleCoopUsers.visibility =  android.view.View.VISIBLE;

                }
                else{
                    chboxGame.setMinAndMaxProgress(0f,0.5f)
                    chboxGame.speed = -1.5f;
                    chboxGame.playAnimation()
                    recycleCoopUsers.visibility = GONE;
                }
            }
            dialog.setView(dialogView);
            dialog.setPositiveButton(getString(R.string.addCounter)) { _: DialogInterface, _: Int -> }
            dialog.setNegativeButton(getString(R.string.dismiss)) { _: DialogInterface, _: Int -> }
            dialog.setTitle("")
            val customDialog = dialog.create();
            btnAddCounter.setOnClickListener{
                chboxCoop.isActivated = AllFriends.isNotEmpty();
                chboxGame.isActivated = AllFriends.isNotEmpty();
                recycleCoopUsers.layoutManager = LinearLayoutManager(this@MainActivity);
                recycleCoopUsers.adapter = AdapterCounterUser(AllFriends,this@MainActivity);
                customDialog.show()
                customDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                    if(txtName.text.isEmpty())
                    {
                        Toast.makeText(this@MainActivity,getString(R.string.needName),Toast.LENGTH_LONG).show()
                        return@setOnClickListener;
                    }
                    if((coopIsChecked || gameIsChecked)&& involvedUsers.filter { it }.isEmpty())
                    {
                        Toast.makeText(
                            this@MainActivity,
                            "You need to select at least 1 person with \"Coop\" or \"Game\" mode selected",
                            Toast.LENGTH_LONG
                        ).show()
                        return@setOnClickListener;
                    }
                    var name = txtName.text.toString();
                    val involvedUsersId:ArrayList<String> = arrayListOf();
                    var i = 0;
                    while(i < AllFriends.size)
                    {
                        if(involvedUsers[i])
                        {
                            involvedUsersId.add(AllFriends[i].id);
                            involvedUsers[i]=false;
                        }
                        ++i;
                    }
                    involvedUsersId.add(currentUser.id)
                    i = 0;
                    var type:CounterTypes;
                    if(coopIsChecked)
                    {
                        type = CounterTypes.Coop;
                    }
                    else if (gameIsChecked)
                    {
                        type = CounterTypes.Game
                    }
                    else
                    {
                        type = CounterTypes.Solo
                    }
                    if(connection)
                    {
                        DatabaseControl.CreateCounter(name,type,involvedUsersId,this@MainActivity,object:CallbackUser{
                            override fun onCallback() {
                                txtName.setText("")
                                coopIsChecked = false;
                                coopIsChecked = false;
                                customDialog.dismiss();
                                chboxCoop.progress = 0f;
                                recycleCoopUsers.visibility = GONE;
                                recCounter.layoutManager = LinearLayoutManager(this@MainActivity);
                                recCounter.adapter = RecyclerAdapter(Mycounters,this@MainActivity);
                                RecycleCurrentPosition = 0;
                            }
                        });
                    }
                    else{
                        OfflineManager.createAction(this,Action.Companion.ActionType.AddCounter,counter = Counter("",0,name,"","",type,involvedUsersId,0))
                        txtName.setText("")
                        coopIsChecked = false;
                        gameIsChecked = false;
                        customDialog.dismiss();
                        chboxCoop.progress = 0f;
                        recycleCoopUsers.visibility = GONE;
                        recCounter.layoutManager = LinearLayoutManager(this@MainActivity);
                        recCounter.adapter = RecyclerAdapter(Mycounters,this@MainActivity);
                        recCounter.startLayoutAnimation();
                        RecycleCurrentPosition = 0;
                    }
                }
            }
        }

        fun duShit(){handler.postDelayed({
            if(!friendsLoaded)
            {
                duShit();
            }
            else{
                progressBarMain.visibility = android.view.View.GONE;
                btnAddCounter.visibility = View.VISIBLE;
                continueMain();
            }
        }, 100);}

        fun Main(){
            val appSharedPrefs: SharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(this)
            val gson = Gson()
            if(connection) {
                DatabaseControl.getCurrentUser(object:CallbackGetCurrentUser{
                    override fun onCallback(user: User) {
                        currentUser = user;
                        val prefsEditor: SharedPreferences.Editor = appSharedPrefs.edit()
                        var json = gson.toJson(user)
                        prefsEditor.putString("CurrentUser", json)
                        prefsEditor.commit()
                        DatabaseControl.initialize(object:CallbackGetCounter{
                            override fun onCallback(list: MutableList<Counter>) {
                                var json = gson.toJson(list)
                                OfflineManager.saveJsonCounters(json,this@MainActivity)
                                Mycounters.clear();
                                Othercounters.clear();
                                list.forEach { counter ->
                                    if(counter.group.isNotEmpty())
                                    {
                                        if(counter.ownerId == DatabaseControl.refAuth.currentUser!!.uid)
                                        {
                                            Mycounters.add(counter);
                                        }
                                        else{
                                            Othercounters.add(counter)
                                        }
                                    }
                                    else{
                                        Mycounters.add(counter);
                                    }
                                }
                                recCounter.layoutManager = LinearLayoutManager(this@MainActivity);
                                recCounter.adapter = RecyclerAdapter(Mycounters,this@MainActivity);
                                /*recCounter.animation = Animation(R.anim.animation_item_layout);
                                fun dushit3(){
                                    handler.postDelayed({
                                        if(recCounter.layoutAnimation != null)
                                        {
                                            if(recCounter.layoutAnimation.)
                                            {
                                                recCounter.layoutAnimation = null;
                                            }else{
                                                dushit3()
                                            }
                                        }},200)
                                        }
                                
                                    recCounter.startLayoutAnimation();
                                    dushit3()*/
                                RecycleCurrentPosition = 0;
                            }
                        },object: CallbackGetFriends{
                            override fun onCallback(list: MutableList<User>) {
                                Log.d("Coop",list.toString());
                                AllFriends = list;
                                friendsLoaded = true;
                                involvedUsers = list.map { false }.toMutableList()

                                var json = gson.toJson(list)
                                OfflineManager.saveJsonFriends(json,this@MainActivity);
                            }
                        },object: CallbackRequest{
                            override fun onCallback(result: MutableList<Request>) {
                                allRequests = result;
                                if( recRequestForMain != null){
                                    recRequestForMain!!.adapter = RecyclerAdapterRequest(
                                        allRequests,this@MainActivity, recRequestForMain!!
                                    )}
                            }
                        })
                        duShit()
                        labelLoggedUser.text = currentUser.userName
                    }
                })}
            else{
                var json = appSharedPrefs.getString("CurrentUser","")
                if(json == "")
                {
                    currentUser = User(DatabaseControl.refAuth.currentUser!!.uid,"You", hashMapOf())
                }
                else{
                    val type = object : TypeToken<User?>() {}.type
                    currentUser = gson.fromJson<User>(json, type)

                }
                labelLoggedUser.text = currentUser.userName
                duShit()
            }
        }

        networkManager.observe(this, Observer { isConnected ->
            connection = isConnected
            if(!connectionChecked){
                Main();
                connectionChecked = true;
            }
            if(isConnected){
                OfflineManager.executeActions(this,object:OfflineCallback{
                    override fun onCallback() {
                        recCounter.adapter = RecyclerAdapter(Mycounters,this@MainActivity)
                    }
                });

                val currentActivity =
                    (findViewById<View>(android.R.id.content) as ViewGroup).getChildAt(0) as ViewGroup
                var wiFi = currentActivity.findViewById<LottieAnimationView>(R.id.wi_fi)
                wiFi.setMinAndMaxProgress(0.5f,1f)
                wiFi.speed = 1f;
                wiFi.playAnimation()
                if(::_menu.isInitialized)
                {
                    _menu.findItem(R.id.menuSignOut).setEnabled(true);
                }
            }
            else if(!isConnected){
                val currentActivity =
                    (findViewById<View>(android.R.id.content) as ViewGroup).getChildAt(0) as ViewGroup
                var wiFi = currentActivity.findViewById<LottieAnimationView>(R.id.wi_fi)
                wiFi.setMinAndMaxProgress(0.5f,1f)
                wiFi.speed = -1f;
                wiFi.playAnimation()
                if(::_menu.isInitialized) {
                    _menu.findItem(R.id.menuSignOut).setEnabled(false);
                }
            }
        })
                }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main,menu)
        _menu = menu!!;
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        if(!connection)
        {
            menu!!.getItem(3)!!.setEnabled(false)
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.menuAbout -> {
                startActivity(Intent(this, About::class.java));
            }
            R.id.menuFeedback -> {
                startActivity(Intent(this, Feedback::class.java));
            }
            R.id.menuSignOut -> {
                DatabaseControl.refAuth.signOut();
                startActivity(Intent(this, login::class.java).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                this.finish()
            }
            R.id.menuFriends -> {
                startActivity(this@MainActivity, Intent(this@MainActivity, friends::class.java), Bundle());
            }
        }
        return super.onOptionsItemSelected(item)
    }
}

/*fun loadFriends(context: Context, intent: Intent)
{
      startActivity(context, intent, Bundle());
}
fun loadFriends(context: Context, recyclerView: RecyclerView)
{
    val gson = Gson()
    if(connection) {
        DatabaseControl.GetFriends(object:CallbackGetFriends{
            override fun onCallback(list: MutableList<User>) {
                Log.d("Coop",list.toString());
                AllFriends = list;
                friendsLoaded = true;
                involvedUsers = list.map { false }.toMutableList()

                recyclerView.layoutManager = LinearLayoutManager(context);
                recyclerView.adapter = AdapterCounterUser(AllFriends,context);

                var json = gson.toJson(list)
                OfflineManager.saveJsonFriends(json,context);
            }
        });
    }
    else{
        var json = OfflineManager.loadFriends(context);
        val type = object : TypeToken<List<User?>?>() {}.type
        val list: List<User>;
        if(json != "-1")
        {
            list = gson.fromJson<List<User>>(json, type)
        }
        else{
            list = listOf()
        }
        friendsLoaded = true;

        AllFriends = list.toMutableList();
        involvedUsers = list.map { false }.toMutableList()
        recyclerView.layoutManager = LinearLayoutManager(context);
        recyclerView.adapter = AdapterCounterUser(AllFriends,context);
    }
}

fun LoadCounters(_recCounter:RecyclerView,_context: Context,btn:FloatingActionButton){
    val gson = Gson()
    if(connection)
    {
        DatabaseControl.GetCounters(DatabaseControl.refAuth.currentUser!!.uid,object:CallbackGetCounter{
            override fun onCallback(list: MutableList<Counter>) {
                var json = gson.toJson(list)
                OfflineManager.saveJsonCounters(json,_context)
                Mycounters.clear();
                Othercounters.clear();
                list.forEach { counter ->
                    if(counter.group.isNotEmpty())
                    {
                        if(counter.ownerId == DatabaseControl.refAuth.currentUser!!.uid)
                        {
                            Mycounters.add(counter);
                        }
                        else{
                            Othercounters.add(counter)
                        }
                    }
                    else{
                        Mycounters.add(counter);
                    }
                }
                _recCounter.layoutManager = LinearLayoutManager(_context);
                _recCounter.adapter = RecyclerAdapter(Mycounters,_context);
                _recCounter.startLayoutAnimation();
                RecycleCurrentPosition = 0;
                btn.visibility = View.VISIBLE;
            }
        })
    }
    else{
        val type = object : TypeToken<List<Counter?>?>() {}.type
        val list: List<Counter>;
        var json = OfflineManager.loadCounters(_context)
        if(json != "-1")
        {
            list = gson.fromJson<List<Counter>>(json, type)
        }
        else{
            list = listOf()
        }
        Mycounters.clear();
        Othercounters.clear();
        list.forEach { counter ->
            if(counter.group.isNotEmpty())
            {
                if(counter.ownerId == DatabaseControl.refAuth.currentUser!!.uid)
                {
                    Mycounters.add(counter);
                }
                else{
                    Othercounters.add(counter)
                }
            }
            else{
                Mycounters.add(counter);
            }
        }
        _recCounter.layoutManager = LinearLayoutManager(_context);
        _recCounter.adapter = RecyclerAdapter(Mycounters,_context);
        _recCounter.startLayoutAnimation();
        RecycleCurrentPosition = 0;
        btn.visibility = View.VISIBLE;
    }
    }
*/


//Animations --------------------------------------------------------------------------------------------------------------------
val rotateCounterClockWise = RotateAnimation(
    0f,
    -360f,
    Animation.RELATIVE_TO_SELF,
    0.5f,
    Animation.RELATIVE_TO_SELF,
    0.5f
)

val rotateClockWise = RotateAnimation(
    0f,
    360f,
    Animation.RELATIVE_TO_SELF,
    0.5f,
    Animation.RELATIVE_TO_SELF,
    0.5f
)
//Animations --------------------------------------------------------------------------------------------------------------------