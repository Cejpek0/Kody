package com.example.coopcounter

import android.content.ContentValues.TAG
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.lang.Exception

interface CallbackUser {
    fun onCallback()
}

interface CallbackCreateCounter {
    fun onCallback(counters: MutableList<String>)
}

interface CallbackGetCounter {
    fun onCallback(list: MutableList<Counter>)
}

interface CallbackGetFriends {
    fun onCallback(list: MutableList<User>)
}

interface CallbackUserExists {
    fun onCallback(userId: String)
}

interface CallbackGetCurrentUser {
    fun onCallback(user: User)
}
interface CallbackBool{
    fun onCallback(isSignedIn:Boolean)
}
interface CallbackRequest{
    fun onCallback(result:MutableList<Request>)
}
class DatabaseControl {
    companion object {
        var context: Context? = null;
        val refData = FirebaseDatabase.getInstance();
        val refUsers = FirebaseDatabase.getInstance().getReference("Users");
        val refCounter = FirebaseDatabase.getInstance().getReference("Counters");
        val refAuth = FirebaseAuth.getInstance();
        val refFeedback = FirebaseDatabase.getInstance().getReference("Feedback");
        val refRequest = FirebaseDatabase.getInstance().getReference("Requests")

        fun initialize(callbackCounter: CallbackGetCounter,callbackFriends: CallbackGetFriends,callbackRequest: CallbackRequest)
        {
                val listenerCounter = object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        var originalCounters = Mycounters.toMutableList()

                        val result = mutableListOf<Counter>();
                        for(ds: DataSnapshot in p0.children)
                        {
                            var _counter = ds.getValue(Counter::class.java)!!
                            if (_counter.InvolvedUsers.contains(currentUser.id)) {
                                result.add(_counter);
                            }
                        }
                        originalCounters.sortBy { it.id }
                        result.sortBy { it.id }
                        if(originalCounters != result)
                        {
                            callbackCounter.onCallback(result)
                            /*if(originalCounters.size != result.size)
                            {
                                callbackCounter.onCallback(result);
                            }else{
                                var difference = result.filterNot { originalCounters.contains(it) }.toMutableList()
                                difference.forEach {counter->
                                    var oCounter = originalCounters.find { it.id == counter.id }
                                       if(oCounter!!.value == counter.value)
                                       {
                                           callbackCounter.onCallback(result)
                                       }
                                }
                            }*/
                        }
                        else if(originalCounters.isEmpty())
                        {
                            callbackCounter.onCallback(result)
                        }
                    }
                    override fun onCancelled(p0: DatabaseError) {
                    }
                }


            val singleCounterListener = object : ValueEventListener{
                override fun onCancelled(error: DatabaseError) {
                }

                override fun onDataChange(snapshot: DataSnapshot) {
                    val result = mutableListOf<Counter>();
                    for (ds: DataSnapshot in snapshot.children) {
                        var _counter = ds.getValue(Counter::class.java)!!
                        if (_counter.InvolvedUsers.contains(currentUser.id)) {
                            refCounter.child(_counter.id).addValueEventListener(listenerCounter)
                        }
                    }
                }
            }

                refCounter.addValueEventListener(listenerCounter)

                val listenerFriends = object : ValueEventListener {
                    val result = arrayListOf<User>()
                    override fun onDataChange(p0: DataSnapshot) {
                        var originalFriends = AllFriends.toMutableList()

                        for (ds: DataSnapshot in p0.children) {
                            var _user = ds.getValue(User::class.java)!!
                            if (currentUser.Friends.contains(_user.id)) {
                                result.add(_user);
                            }
                        }
                        originalFriends.sortBy { it.id }
                        result.sortBy { it.id }
                        if(originalFriends != result)
                        {
                            callbackFriends.onCallback(result)
                        }
                        else if(originalFriends.isEmpty())
                        {
                            callbackFriends.onCallback(result)
                        }

                    }

                    override fun onCancelled(p0: DatabaseError) {

                    }
                }
                refUsers.addValueEventListener(listenerFriends)

                val listenerRequests = object : ValueEventListener {
                    override fun onDataChange(p0: DataSnapshot) {
                        var originalRequests = allRequests.toMutableList()
                        val result = mutableListOf<Request>();
                        for (ds: DataSnapshot in p0.children) {
                            var _request = ds.getValue(Request::class.java)!!
                            if (_request.users.contains(currentUser.userName)) {
                                result.add(_request);
                            }
                        }
                        originalRequests.sortBy { it.id }
                        result.sortBy { it.id }
                        if(originalRequests!=result)
                        {
                                callbackRequest.onCallback(result);
                        }
                        else if(originalRequests.isEmpty())
                        {
                            callbackRequest.onCallback(result)
                        }
                    }
                    override fun onCancelled(p0: DatabaseError) {
                    }
                }
                refRequest.addValueEventListener(listenerRequests)
        }

        fun getCurrentUser(callback: CallbackGetCurrentUser) {
            val singleUserListener = object : ValueEventListener {

                override fun onDataChange(p0: DataSnapshot) {
                    callback.onCallback(p0.child(refAuth.currentUser!!.uid).getValue(User::class.java)!!
                    )

                }

                override fun onCancelled(p0: DatabaseError) {}
            }
            refUsers.addListenerForSingleValueEvent(singleUserListener)
        }

        fun CreateUser(mail: String, password: String, username: String,context: Context, callback: CallbackUser) {
            val singleCounterListener = object : ValueEventListener {
                override fun onDataChange(p0: DataSnapshot) {
                    val data = mutableListOf<User>();
                    for (ds: DataSnapshot in p0.children) {
                        data.add(ds.getValue(User::class.java)!!);
                    }
                    Log.d("Kamo", p0.value.toString());
                    Log.d("Kamo", data.find { it.userName == username }.toString());
                    if (data.find { it.userName == username } == null) {
                        refAuth.createUserWithEmailAndPassword(mail, password)
                            .addOnCompleteListener() { task ->
                                if (task.isSuccessful) {
                                    task.result
                                    val user =
                                        User(refAuth.currentUser!!.uid, username, hashMapOf());
                                    refUsers.child(refAuth.currentUser!!.uid).setValue(user);
                                    callback.onCallback();
                                } else {
                                    if (task.exception is FirebaseAuthUserCollisionException) {
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.mailExist),
                                            Toast.LENGTH_SHORT
                                        ).show();
                                    } else if (task.exception is FirebaseAuthWeakPasswordException) {
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.weakPass),
                                            Toast.LENGTH_SHORT
                                        ).show();
                                    }  else if(task.exception is FirebaseAuthEmailException) {
                                        Toast.makeText(context, context.getString(R.string.emailWrong), Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(context, "Error (" + task.exception!!.message+")", Toast.LENGTH_SHORT).show();
                                    }

                                }

                            };
                    } else {
                        Toast.makeText(
                            context,
                            context.getString(R.string.usernameTaken),
                            Toast.LENGTH_LONG
                        ).show();
                    }
                }

                override fun onCancelled(p0: DatabaseError) {}
            }
            refUsers.addListenerForSingleValueEvent(singleCounterListener);
        }

        fun LoginUser(mail: String, password: String, callback: CallbackBool) {
            refAuth.signInWithEmailAndPassword(mail, password).addOnCompleteListener() { task ->
                if (task.isSuccessful) {
                    callback.onCallback(true);
                } else {
                    callback.onCallback(false)
                }
            };
        }


        fun CreateCounter(
            name: String,
            type: CounterTypes,
            involvedUsers: ArrayList<String>,
            context: Context,
            callback: CallbackUser
        ) {
            var counter: Counter;
            var counterGroup = (1..20).map { (('A'..'Z') + ('a'..'z') + ('0'..'9')).random() }.joinToString("")

            when (type) {
                CounterTypes.Solo -> {
                    var counterId = refCounter.push().key!!
                    counter =
                        Counter(counterId, 0, name, "","", type, arrayListOf(currentUser.id),0)
                    refCounter.child(counterId).setValue(counter).addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            callback.onCallback()
                        } else {
                            Toast.makeText(
                                context,
                                context.getString(R.string.counterError),
                                Toast.LENGTH_SHORT
                            ).show();
                        }
                    }
                }
                CounterTypes.Coop -> {
                    var counterId = refCounter.push().key!!
                    counter = Counter(counterId, 0, name, "","", type, involvedUsers,0)
                    refCounter.child(counterId).setValue(counter).addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            callback.onCallback()
                        } else {
                            Toast.makeText(
                                context,
                                context.getString(R.string.counterError),
                                Toast.LENGTH_SHORT
                            ).show();
                        }
                    }
                }
                CounterTypes.Game -> {
                    for(user in involvedUsers)
                    {
                        var counterId = refCounter.push().key!!
                        counter = Counter(counterId, 0, name, user,counterGroup, type, involvedUsers,0)
                        refCounter.child(counterId).setValue(counter).addOnCompleteListener { task ->
                            if (!task.isSuccessful) {
                                Toast.makeText(context, context.getString(R.string.counterError), Toast.LENGTH_SHORT).show();
                            }
                    }
                    callback.onCallback()
                }

            }

        }}

        fun SendFeedback(text: String,callback: CallbackBool)
        {

            refFeedback.child(refFeedback.push().key!!).setValue(text).addOnCompleteListener{
                if(it.isSuccessful)
                {
                    callback.onCallback(true)
                }
                else{
                    callback.onCallback(false)
                }
            }
        }

        fun CreateRequest(_userName:String, context: Context,callback: CallbackUser){
            val request = Request(refRequest.push().key!!, listOf(currentUser.userName,_userName))
            refRequest.child(request.id).setValue(request).addOnCompleteListener{task->
                if(task.isSuccessful)
                {
                    Toast.makeText(context, context.getString(R.string.requestSent), Toast.LENGTH_SHORT).show();
                    callback.onCallback();
                } else{
                    Toast.makeText(context, "Error ("+task.exception!!.message+")", Toast.LENGTH_SHORT)
                        .show();
                }
            }
        }
        fun RemoveRequest(requestId:String, callback: CallbackUser){
            refRequest.child(requestId).removeValue()
            callback.onCallback()
        }
        //TODO on change k referenci na requesty
    fun CreateFriendship(userId: String,_userName:String,context: Context, callback: CallbackUser) {
        refUsers.child(refAuth.currentUser!!.uid).child("Friends").child(userId).setValue(userId)//TODO Add ne replace
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    refUsers.child(userId).child("Friends").child(refAuth.currentUser!!.uid).setValue(refAuth.currentUser!!.uid)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                AllFriends.add(User(userId,_userName, hashMapOf()))
                                currentUser.Friends.put(userId,userId)
                                Toast.makeText(context, context.getString(R.string.friendAdded), Toast.LENGTH_SHORT).show();
                                callback.onCallback();
                            } else {
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.friendAddError),
                                    Toast.LENGTH_SHORT
                                ).show();
                                refUsers.child(refAuth.currentUser!!.uid).child("Friends")
                                    .child(userId).removeValue()
                            }
                        }
                } else {
                    Toast.makeText(context, context.getString(R.string.friendAddError), Toast.LENGTH_SHORT)
                        .show();
                }
            }
    }

    fun RemoveFriendship(
        userId: String,
        context: Context,
        callback: CallbackUser) {
        refUsers.child(refAuth.currentUser!!.uid).child("Friends").child(userId).removeValue()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    refUsers.child(userId).child("Friends").child(refAuth.currentUser!!.uid)
                        .removeValue().addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                Toast.makeText(context, context.getString(R.string.friendRemoved), Toast.LENGTH_SHORT)
                                    .show();
                                callback.onCallback();
                            } else {
                                Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                            }
                        }
                } else {
                    Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                }
            };
    }


    fun UpdateCount(counterId: String, increaseBy: Int,callback: CallbackUser = object:CallbackUser{
        override fun onCallback() {} }) {
        val singleCounterListener = object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {
                val data = mutableListOf<Counter>();
                var value = 0;
                    value = p0.getValue(Counter::class.java)!!.value;
                Log.d("Kamo", p0.value.toString());
                Log.d("Kamo", data.find { it.id == counterId }.toString());
                refCounter.child(counterId).child("value")
                    .setValue(value + increaseBy)
                    .addOnCompleteListener { task ->
                    }
                callback.onCallback();
            }

            override fun onCancelled(p0: DatabaseError) {
            }
        }
        refCounter.child(counterId).addListenerForSingleValueEvent(singleCounterListener);
    }

    fun UserExists(username: String, callback: CallbackUserExists) {
        var userId = "";
        val singleCounterListener = object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {
                for (ds: DataSnapshot in p0.children) {
                    var objekt = ds.getValue(User::class.java)!!;
                    var _userName = objekt.userName;
                    if (_userName == username) {
                        userId = objekt.id;
                        break;
                    }
                }
                callback.onCallback(userId);
            }

            override fun onCancelled(p0: DatabaseError) {
            }
        }


        refUsers.addListenerForSingleValueEvent(singleCounterListener);
    }

    fun removeCounter(counter: Counter, callback: CallbackUser) {
        when (counter.type) {
            CounterTypes.Solo -> {
                refCounter.child(counter.id).removeValue()
                Mycounters.remove(counter)
            }
            CounterTypes.Coop -> {
                counter.InvolvedUsers.remove(currentUser.id)
                if(counter.InvolvedUsers.count() == 0)
                {
                    refCounter.child(counter.id).removeValue()
                }
                else{
                    refCounter.child(counter.id).child("involvedUsers").setValue(counter.InvolvedUsers)
                }
                Mycounters.remove(counter)
            }
            CounterTypes.Game -> { //TODO Vymazat referenci ostatním
                refCounter.child(counter.id).removeValue()
                Mycounters.remove(counter)
                Othercounters.filter { it.group == counter.group }.forEach{_counter ->
                    _counter.InvolvedUsers.remove(currentUser.id)
                    refCounter.child(_counter.id).child("involvedUsers").child(currentUser.id).removeValue()
                }
            }
        }
        callback.onCallback()
    }
}}